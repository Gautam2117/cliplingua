import crypto from "crypto";
import { supabaseAdmin } from "@/lib/supabase-admin";

function getApiKeyFromReq(req: Request) {
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  const bearer = m?.[1]?.trim();

  const headerKey = req.headers.get("x-api-key")?.trim();
  const key = bearer || headerKey || "";

  return key;
}

function parsePrefix(apiKey: string) {
  // expected: clp_PREFIX_SECRET
  const parts = apiKey.split("_");
  if (parts.length < 3) return null;
  if (parts[0] !== "clp") return null;
  const prefix = String(parts[1] || "").trim().toUpperCase();
  if (!prefix) return null;
  return prefix;
}

function sha256Hex(input: string) {
  return crypto.createHash("sha256").update(input, "utf8").digest("hex");
}

export async function requireApiOrg(req: Request) {
  const apiKey = getApiKeyFromReq(req);
  if (!apiKey) {
    return { ok: false as const, status: 401, error: "Missing API key" };
  }

  const prefix = parsePrefix(apiKey);
  if (!prefix) {
    return { ok: false as const, status: 401, error: "Invalid API key format" };
  }

  const keyHash = sha256Hex(apiKey);

  const { data, error } = await supabaseAdmin
    .from("org_api_keys")
    .select("org_id,prefix,revoked_at")
    .eq("prefix", prefix)
    .eq("key_hash", keyHash)
    .is("revoked_at", null)
    .limit(1)
    .maybeSingle();

  if (error) {
    return { ok: false as const, status: 500, error: error.message };
  }

  if (!data?.org_id) {
    return { ok: false as const, status: 401, error: "Invalid or revoked API key" };
  }

  return { ok: true as const, orgId: String(data.org_id), prefix: String(data.prefix) };
}
